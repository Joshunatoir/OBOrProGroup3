import java.util.ArrayList;
import java.util.Scanner;

public class AppDriver {
    public static void main(String[] args) {
    	
    	Scanner sc = new Scanner(System.in);
        ArrayList<Movie> movieList = MovieManager.loadMovieList();
        MovieManager manager = new MovieManager(); 

        manager.loadMovieList();
        manager.displayMenu(movieList,sc);
        manager.saveMovieListToFile(movieList); 
    }
}

    