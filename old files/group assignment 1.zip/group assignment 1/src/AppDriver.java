import java.util.ArrayList;
import java.util.Scanner;

public class AppDriver {
    public static void main(String[] args) {
    	
        ArrayList<Movie> movieList = MovieManager.loadMovieList();
        MovieManager manager = new MovieManager(); 

        manager.loadMovieList();
        manager.displayMenu(movieList);
        manager.saveMovieListToFile(movieList); 
    }
}

    